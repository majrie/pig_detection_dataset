License: CC BY 4.0
This work is licensed under the Creative Commons Attribution 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
Copyright (c) 2022 Martin Riekert

Please cite our paper: 
Martin Riekert, Svenja Opderbeck, Andrea Wild, Eva Gallmann, 
Model selection for 24/7 pig position and posture detection by 2D camera imaging and deep learning,
Computers and Electronics in Agriculture, Volume 187, 2021, 106213, ISSN 0168-1699, https://doi.org/10.1016/j.compag.2021.106213.

I am happy to hear from your research, so do not hesitate to contact me.
- Martin (dr.martin.riekert@gmail.com)

################################################################################################
README
The json files contain the annotations of the pigs in the images in the dataset.
The tool sloth can be used to view the annotations and was used to annotate them https://github.com/cvhciKIT/sloth. 
Two images of the image dataset cannot be published. The images not published are C10220180530-131259-1527678779_3077s (Validation, 03_C102_day) and C201-20181202-100048-1543741248_2596s (Test, 04_C201_day). The images were removed from the public dataset, but the annotations for these images are kept in the public dataset for transparency. The annotations in the json files for the removed images might need to be removed before usage of the dataset in your own experiments.
Before the usage of the dataset, we recommend the application of these preprocessing steps, which were also applied by us:
Some bounding boxes reach over the borders of the image, because sloth does not restrict the annotation to the image border. During preprocessing of the dataset, we assured that the affected bounding box is inside the border of the image. For this purpose, we set the border of the bounding box to the border of the image wherever the bounding box overlapped.
There are few annotations that are very small. We removed these annotations from the dataset.
The coordinates provided in the annotations by the tool “sloth” are absolute values of the position of the bounding box in the image. Many deep learning frameworks will require you to process these values into the relative position of the annotation in the image. We processed the values in our paper in such a way that they became relative values.

For the training set we reused annotations from our previous publication:
Martin Riekert, Achim Klein, Felix Adrion, Christa Hoffmann, Eva Gallmann, Automatically detecting pig position and posture by 2D camera imaging and deep learning, Computers and Electronics in Agriculture, Volume 174, 2020, 105391, ISSN 0168-1699, https://doi.org/10.1016/j.compag.2020.105391.

FURTHER INFORMATION
Further information concerning the dataset can be found here: https://www.sciencedirect.com/science/article/pii/S0168169921002301 and https://www.sciencedirect.com/science/article/pii/S0168169918318283 
The annotations for training and test set can be viewed in Appendix A. Supplementary material of the COMPAG 2021 paper: https://www.sciencedirect.com/science/article/pii/S0168169921002301#s0080 


Acknowledgements
We thank Endrit Tejeci, Tobias Zimpel and Steve Tshisola for annotating this dataset. We thank the staff at the Boxberg Teaching and Research Centre – Centre for pig rearing and pig breeding (LSZ Boxberg) for their support and advise during the experiments, especially Hansjörg Schrade, Barbara Keßler, Max Staiger, Karen Kauselmann and William Gordillo. We thank the LABEL-FIT project team, especially Benedikt Glitz, who allowed us to use their video recordings. We thank Prof. Dr. Stefan Kirn and Dr. Jörg Leukel (University of Hohenheim) for discussions and ideas. We thank the machine learning community for providing many free resources for our research. This work was supported by the project “Landwirtschaft 4.0: Info-System”, funded by the Ministry of Rural Development and Consumer Protection of Baden-Württemberg. This work was also supported by the project LABEL-FIT by funds of the Federal Ministry of Food and Agriculture (BMEL) based on a decision of the Parliament of the Federal Republic of Germany via the Federal Office for Agriculture and Food (BLE) under the innovation support programme (2819200415).
################################################################################################
